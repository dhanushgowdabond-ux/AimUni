# AimUni MERN source

This workspace contains the AimUni React website, Express/Node API, and MongoDB/Mongoose consultation storage.

## MongoDB setup

- Create a MongoDB database named `aimuni` (MongoDB Atlas is one option).
- Copy `artifacts/api-server/.env.example` to `artifacts/api-server/.env` for local use, or add `MONGODB_URI` to Replit Secrets.
- Replace the example URI with your private MongoDB connection URI. Do not commit the real URI or share it in chat.

The API stores submitted consultations in the `consultation_requests` collection. Without a configured URI, the API returns a clear error and does not claim a request was saved.

## Backend files

- `artifacts/api-server/src/lib/mongodb.ts` — MongoDB connection and connection state
- `artifacts/api-server/src/models/Consultation.ts` — Mongoose document schema
- `artifacts/api-server/src/routes/consultations.ts` — validated endpoint that saves consultation requests
- `lib/api-spec/openapi.yaml` — shared API contract used to generate client and validation types

## Run in the Replit workspace

The project uses pnpm workspaces and Replit's path-based preview routing:

```sh
pnpm install
```

Start the managed `artifacts/api-server: API Server` and `artifacts/aimuni-website: web` workflows from the Replit workspace. They supply the ports and preview routing required by the two artifacts.

The consultation form sends `POST /api/consultations`. It stores the student's name, email, destination, study level, and server-generated timestamp. Contact links open email, WhatsApp at +91 97398 81992, and phone at +91 90353 51000.