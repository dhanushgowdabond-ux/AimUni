import { type FormEvent, type ReactNode, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  ArrowDownRight,
  ArrowRight,
  BookOpen,
  Check,
  ChevronDown,
  Clock3,
  Compass,
  Globe2,
  GraduationCap,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Plane,
  Phone,
  Search,
  ShieldCheck,
  Sparkles,
  Users,
  WalletCards,
  X,
} from 'lucide-react';
import { useCreateConsultation, type ConsultationInput } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';

const queryClient = new QueryClient();

type Country = {
  name: string;
  city: string;
  image: string;
  note: string;
  tags: string[];
  accent: string;
};

const countries: Country[] = [
  { name: 'United Kingdom', city: 'London, Manchester & beyond', image: '/assets/uk.avif', note: 'World-class universities with a direct route to your future.', tags: ['1-year master’s', 'Global rankings'], accent: '#d8664d' },
  { name: 'Canada', city: 'Toronto, Vancouver & Montreal', image: '/assets/canada.avif', note: 'A welcoming, practical education system built for global careers.', tags: ['Post-study work', 'Safe & welcoming'], accent: '#bb5948' },
  { name: 'Ireland', city: 'Dublin & Galway', image: '/assets/ireland.webp', note: 'Tech, culture and a close-knit student experience in one place.', tags: ['English-taught', 'Tech hub'], accent: '#4e7a68' },
  { name: 'Netherlands', city: 'Amsterdam, Delft & Rotterdam', image: '/assets/netherlands.jpg', note: 'Innovative teaching, bicycles and a truly international classroom.', tags: ['Applied learning', 'EU access'], accent: '#d78943' },
  { name: 'France', city: 'Paris, Lyon & Toulouse', image: '/assets/france.webp', note: 'Ambitious schools, rich culture and value that travels with you.', tags: ['Creative industries', 'Scholarships'], accent: '#d6a248' },
  { name: 'Germany', city: 'Berlin, Munich & Hamburg', image: '/assets/germany.jpg', note: 'Research-led study and a strong launchpad for engineering careers.', tags: ['Low tuition', 'Engineering'], accent: '#9d654c' },
  { name: 'Australia', city: 'Sydney, Melbourne & Brisbane', image: '/assets/australia.webp', note: 'Big ideas, bigger horizons and a vibrant student life.', tags: ['Flexible work', 'Sunny cities'], accent: '#ce7b39' },
  { name: 'Czechia', city: 'Prague & Brno', image: '/assets/czechia.jpg', note: 'Beautiful cities and a smart, accessible European education.', tags: ['Value-led', 'Historic cities'], accent: '#4f7c83' },
  { name: 'United States', city: 'New York, Boston & beyond', image: '/assets/usa.jpg', note: 'Choose your pace, your campus and the story you want to write.', tags: ['Research', 'Campus life'], accent: '#54709b' },
  { name: 'Poland', city: 'Warsaw, Kraków & Gdańsk', image: '/assets/poland.jpg', note: 'Fast-growing cities with ambitious programmes and real value.', tags: ['Affordable', 'Growing market'], accent: '#ad6044' },
];

const fields = [
  { label: 'Business & leadership', title: 'Build a career that can cross borders.', body: 'From entrepreneurship to finance, find programmes that put you close to ambitious companies and practical experience.', icon: WalletCards, stat: 'Practical fit' },
  { label: 'Computing & technology', title: 'Turn curiosity into your next advantage.', body: 'Compare specialist labs, co-op routes and the cities where the world’s next big ideas are being built.', icon: Sparkles, stat: 'Career direction' },
  { label: 'Engineering', title: 'Make the future tangible.', body: 'Get clear on accreditation, research fit and the real-world outcomes behind each engineering degree.', icon: Compass, stat: 'Clear requirements' },
  { label: 'Health & life sciences', title: 'Study work that matters.', body: 'We help you navigate entry requirements, clinical pathways and the right preparation for a meaningful career.', icon: ShieldCheck, stat: 'Personal support' },
];

const steps = [
  { number: '01', title: 'Tell us your direction', body: 'A relaxed first conversation to understand your goals, budget, strengths and the life you want abroad.', icon: MessageCircle },
  { number: '02', title: 'Shape your shortlist', body: 'We match you with countries, universities and courses that make sense for your story — not just a search result.', icon: Search },
  { number: '03', title: 'Make the application count', body: 'From documents to personal statements, your counsellor keeps every detail clear, honest and on track.', icon: BookOpen },
  { number: '04', title: 'Secure your next step', body: 'We support offer decisions, scholarships and visa preparation with calm, practical guidance.', icon: GraduationCap },
  { number: '05', title: 'Arrive with a plan', body: 'Pre-departure sessions and arrival support mean you land ready to begin, not figure everything out alone.', icon: Plane },
];

const faqs = [
  ['When should I start planning?', 'The earlier the better, especially for competitive courses and scholarship deadlines. For most September intakes, we recommend starting 9–12 months ahead. If your deadline is closer, talk to us anyway — we will give you an honest route forward.'],
  ['How do I know which country is right for me?', 'There is no universal best destination. We look at your academic profile, budget, preferred lifestyle, career plans and how much support you want after graduation, then show you the trade-offs clearly.'],
  ['Can you help with scholarships and funding?', 'Yes. We help you identify relevant scholarships, understand eligibility, build a stronger application and keep an eye on deadlines. We also help you plan the full cost, from tuition to the first month abroad.'],
  ['Do you support students after they are admitted?', 'Absolutely. AimUni goes beyond admission. We support visa preparation, accommodation research, pre-departure planning and your first practical questions after you arrive.'],
  ['What happens in the first consultation?', 'You bring your questions; we bring a clear framework. We will discuss your goals, current profile and possible routes, then agree on useful next steps. There is no pressure to commit on the call.'],
  ['Why do I need IELTS to study abroad?', 'IELTS is one of the most widely accepted ways to show that you can study, communicate and participate confidently in an English-speaking academic environment. Your exact score depends on the university and course.'],
  ['Can I study abroad without IELTS?', 'Some universities accept other evidence, such as previous English-medium education or another approved test. We check the current requirement for each course instead of making assumptions.'],
  ['How much money should I plan for?', 'Costs depend on the country, course and city. We help you compare tuition, living costs, visa requirements and available funding before you make a decision.'],
];

function scrollToSection(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [fieldIndex, setFieldIndex] = useState(0);
  const [faqOpen, setFaqOpen] = useState<number | null>(0);
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);
  const [consultOpen, setConsultOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionError, setSubmissionError] = useState<string | null>(null);
  const createConsultation = useCreateConsultation();
  const field = fields[fieldIndex];
  const FieldIcon = field.icon;

  const openConsult = () => {
    setConsultOpen(true);
    setSubmitted(false);
    setSubmissionError(null);
    setMenuOpen(false);
  };

  const submitConsult = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const data: ConsultationInput = {
      name: String(formData.get('name') ?? '').trim(),
      email: String(formData.get('email') ?? '').trim(),
      country: String(formData.get('country') ?? 'Not sure yet'),
      level: String(formData.get('level') ?? 'Still exploring') as ConsultationInput['level'],
    };

    setSubmissionError(null);
    setIsSubmitting(true);
    try {
      await createConsultation.mutateAsync({ data });
      setSubmitted(true);
    } catch (error) {
      const apiError = error as { data?: { error?: string } };
      setSubmissionError(apiError.data?.error ?? 'We could not save your request. Please try again or contact Priyanka by email or phone.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="min-h-[100dvh] bg-background text-foreground">
      <div className="bg-[#1d2b44] px-4 py-2.5 text-center text-[11px] font-semibold tracking-[0.12em] text-[#f9f5ec]">
        <span className="text-[#f27a5f]">AIMUNI STUDY ABROAD GUIDANCE</span>
        <span className="mx-2 opacity-40">·</span>
        Personal support from your first question to your first day abroad.
      </div>

      <header className="sticky top-0 z-40 border-b border-[#e8e0d2] bg-[#faf8f2]/95 backdrop-blur-md">
        <div className="section-wrap flex h-[76px] items-center justify-between">
          <button type="button" onClick={() => scrollToSection('top')} className="flex items-center" data-testid="button-logo">
            <img src="/assets/aimuni-logo-cropped.png" alt="AimUni — Beyond Admission. Beyond Arrival." className="h-12 w-[150px] object-contain" />
          </button>
          <nav className="hidden items-center gap-8 text-sm font-semibold text-[#33435e] lg:flex" aria-label="Main navigation">
            {[
              ['Destinations', 'destinations'],
              ['How it works', 'process'],
              ['Study fields', 'fields'],
              ['Scholarships', 'scholarships'],
              ['FAQs', 'faqs'],
            ].map(([label, id]) => (
              <button key={id} type="button" onClick={() => scrollToSection(id)} className="transition-colors hover:text-[#e45e48]" data-testid={`link-nav-${id}`}>
                {label}
              </button>
            ))}
          </nav>
          <div className="hidden items-center gap-4 lg:flex">
            <a href="mailto:infoaimuni@gmail.com" className="text-sm font-semibold text-[#33435e] hover:text-[#e45e48]" data-testid="button-nav-contact">Talk to an adviser</a>
            <button type="button" onClick={openConsult} className="rounded-full bg-[#ef654e] px-5 py-3 text-sm font-bold text-white shadow-[0_8px_20px_rgba(239,101,78,.2)] transition-transform hover:-translate-y-0.5" data-testid="button-nav-consultation">
              Book a free call
            </button>
          </div>
          <button type="button" className="rounded-full p-2 text-[#1d2b44] lg:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation" data-testid="button-mobile-menu">
            {menuOpen ? <X size={23} /> : <Menu size={23} />}
          </button>
        </div>
        {menuOpen && (
          <div className="border-t border-[#e8e0d2] bg-[#faf8f2] px-5 py-5 lg:hidden">
            <nav className="flex flex-col gap-4 text-sm font-semibold text-[#33435e]">
              {[
                ['Destinations', 'destinations'],
                ['How it works', 'process'],
                ['Study fields', 'fields'],
                ['Scholarships', 'scholarships'],
                ['FAQs', 'faqs'],
              ].map(([label, id]) => (
                <button key={id} type="button" onClick={() => { scrollToSection(id); setMenuOpen(false); }} className="text-left" data-testid={`link-mobile-${id}`}>{label}</button>
              ))}
              <button type="button" onClick={openConsult} className="mt-2 rounded-full bg-[#ef654e] px-5 py-3 text-center font-bold text-white" data-testid="button-mobile-consultation">Book a free call</button>
            </nav>
          </div>
        )}
      </header>

      <section id="top" className="paper-noise relative overflow-hidden bg-[#f2ecdf]">
        <div className="hero-grid absolute inset-0 opacity-60" />
        <div className="section-wrap relative grid min-h-[660px] items-center gap-10 py-16 md:min-h-[720px] md:grid-cols-[1.04fr_.96fr] md:py-24">
          <div className="reveal-up relative z-10 max-w-[650px]">
            <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-[#d6cbb9] bg-[#fbf8f1] px-3.5 py-2 text-[11px] font-bold uppercase tracking-[0.12em] text-[#527262]">
              <Globe2 size={14} /> A clearer way to study abroad
            </div>
            <h1 className="font-display max-w-[640px] text-[clamp(3.7rem,8vw,7.6rem)] leading-[.9] tracking-[-0.065em] text-[#1d2b44]">
              Your world<br /><span className="text-[#e85f4b]">starts here.</span>
            </h1>
            <p className="mt-7 max-w-[485px] text-lg leading-8 text-[#526078] md:text-[20px]">
              Choosing where to study is a big decision. We make it feel possible — with expert guidance from your first question to your first day abroad.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <button type="button" onClick={openConsult} className="group inline-flex items-center justify-center gap-3 rounded-full bg-[#ef654e] px-6 py-4 text-sm font-bold text-white shadow-[0_10px_24px_rgba(239,101,78,.24)] transition-all hover:-translate-y-1 hover:shadow-[0_14px_30px_rgba(239,101,78,.3)]" data-testid="button-hero-consultation">
                Start with a free consultation <ArrowRight size={17} className="transition-transform group-hover:translate-x-1" />
              </button>
              <button type="button" onClick={() => scrollToSection('destinations')} className="inline-flex items-center justify-center gap-2 rounded-full border border-[#c9bead] bg-[#f8f4eb]/70 px-6 py-4 text-sm font-bold text-[#1d2b44] transition-colors hover:border-[#1d2b44]" data-testid="button-hero-destinations">
                Explore destinations <ArrowDownRight size={16} />
              </button>
            </div>
            <div className="mt-12 flex items-center gap-4 text-sm text-[#526078]">
              <div className="flex -space-x-2">
                {['A', 'M', 'R', 'S'].map((initial, index) => <span key={initial} className={`grid h-8 w-8 place-items-center rounded-full border-2 border-[#f2ecdf] text-[10px] font-bold text-white ${['bg-[#527262]', 'bg-[#d28847]', 'bg-[#e85f4b]', 'bg-[#6d7e9e]'][index]}`}>{initial}</span>)}
              </div>
              <span>Personal guidance for students and families</span>
            </div>
          </div>
          <div className="relative mx-auto h-[430px] w-full max-w-[510px] md:h-[570px]">
            <div className="absolute right-[4%] top-[8%] h-[82%] w-[76%] rounded-[48%] bg-[#d9e4da]" />
            <div className="float-slow absolute inset-[1%] z-10">
              <img src="/assets/aimuni-globe.png" alt="Illustrated globe surrounded by books, landmarks and a graduation cap" className="h-full w-full object-contain drop-shadow-[0_24px_26px_rgba(29,43,68,.14)]" />
            </div>
            <div className="float-slow-reverse absolute bottom-[7%] left-[0%] z-20 rounded-2xl border border-white/60 bg-[#fffaf0]/90 p-4 shadow-[0_16px_30px_rgba(29,43,68,.12)] backdrop-blur-sm">
              <div className="flex items-center gap-3">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-[#ef654e] text-white"><MapPin size={17} /></span>
                <div><p className="text-xs font-bold text-[#1d2b44]">Where will you go?</p><p className="text-[11px] text-[#6b7587]">Global destinations, one right fit</p></div>
              </div>
            </div>
            <div className="absolute right-[4%] top-[9%] z-20 grid h-14 w-14 place-items-center rounded-full bg-[#ef654e] text-white shadow-lg"><ArrowDownRight size={22} /></div>
          </div>
        </div>
        <div className="section-wrap relative grid gap-4 border-t border-[#d9cfbf] py-6 text-sm text-[#526078] sm:grid-cols-3">
          {[['Personal', 'guidance'], ['Global', 'destinations'], ['Beyond', 'admission & arrival']].map(([value, label]) => <div key={label} className="flex items-baseline gap-2 sm:justify-center"><strong className="font-display text-3xl text-[#1d2b44]">{value}</strong><span>{label}</span></div>)}
        </div>
      </section>

      <section className="bg-[#faf8f2] py-20 md:py-28">
        <div className="section-wrap grid gap-10 lg:grid-cols-[.78fr_1.22fr] lg:items-center">
          <div>
            <p className="eyebrow text-[#527262]">For students with big plans</p>
            <h2 className="font-display mt-4 text-5xl leading-[.98] tracking-[-.045em] text-[#1d2b44] md:text-6xl">Start with a dream.<br /><em className="text-[#e85f4b]">Leave with a plan.</em></h2>
            <p className="mt-6 max-w-[430px] leading-7 text-[#687287]">Whether you are still exploring or already comparing universities, we make the next step easier to see. Ask Priyanka a question and get a clear place to begin.</p>
            <a href="mailto:infoaimuni@gmail.com" className="mt-7 inline-flex items-center gap-2 rounded-full border border-[#b9cabb] px-5 py-3 text-sm font-bold text-[#527262] transition-colors hover:bg-[#e9f0e8]" data-testid="button-dream-email">Ask a question by email <ArrowRight size={15} /></a>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <figure className="overflow-hidden rounded-[1.75rem] bg-[#e9f0e8]">
              <img src="/assets/aimuni-student-dreams.jpeg" alt="Student imagining university and travel possibilities" className="aspect-[1.18] h-full w-full object-cover" />
            </figure>
            <figure className="overflow-hidden rounded-[1.75rem] bg-[#f8e6dc] sm:translate-y-8">
              <img src="/assets/aimuni-world-journey.jpeg" alt="Illustrated study abroad journey with books, travel and world landmarks" className="aspect-[1.18] h-full w-full object-cover" />
            </figure>
          </div>
        </div>
      </section>

      <section id="destinations" className="scroll-mt-20 bg-[#faf8f2] py-24 md:py-32">
        <div className="section-wrap">
          <div className="mb-12 flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div className="max-w-[600px]">
              <p className="eyebrow text-[#e85f4b]">Find your place in the world</p>
              <h2 className="font-display mt-4 text-5xl leading-[.98] tracking-[-.045em] text-[#1d2b44] md:text-7xl">The right destination<br /><em className="text-[#527262]">changes everything.</em></h2>
            </div>
            <p className="max-w-[290px] text-sm leading-6 text-[#687287]">Every country has a different rhythm, price tag and path to opportunity. We help you choose with your whole life in mind.</p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {countries.map((country, index) => (
              <article key={country.name} className={`group relative overflow-hidden rounded-[1.35rem] bg-[#1d2b44] text-white ${index === 0 ? 'sm:col-span-2 lg:col-span-2 lg:row-span-2' : ''}`} data-testid={`card-destination-${country.name.toLowerCase().replaceAll(' ', '-')}`}>
                <img src={country.image} alt={`${country.name} study destination`} loading="lazy" className={`absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105 ${index === 0 ? 'min-h-[370px]' : 'min-h-[260px]'}`} />
                <div className="absolute inset-0 bg-gradient-to-t from-[#101b2d] via-[#101b2d]/30 to-transparent" />
                <div className={`relative flex ${index === 0 ? 'min-h-[430px]' : 'min-h-[260px]'} flex-col justify-end p-5`}>
                  <span className="mb-3 w-fit rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.12em] backdrop-blur-sm">{country.city}</span>
                  <h3 className="font-display text-3xl leading-none">{country.name}</h3>
                  <p className="mt-2 max-w-[280px] text-xs leading-5 text-white/75">{country.note}</p>
                  <div className="mt-4 flex flex-wrap gap-1.5">{country.tags.map(tag => <span key={tag} className="rounded-full border border-white/25 px-2 py-1 text-[10px] text-white/85">{tag}</span>)}</div>
                  <button type="button" onClick={() => setSelectedCountry(country)} className="mt-5 flex w-fit items-center gap-2 text-xs font-bold text-white transition-colors hover:text-[#ffb09e]" data-testid={`button-explore-${country.name.toLowerCase().replaceAll(' ', '-')}`}>
                    Explore {country.name} <ArrowRight size={14} />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="fields" className="scroll-mt-20 bg-[#e9f0e8] py-24 md:py-32">
        <div className="section-wrap grid gap-12 lg:grid-cols-[.7fr_1.3fr] lg:items-center">
          <div>
            <p className="eyebrow text-[#527262]">Make a smart subject choice</p>
            <h2 className="font-display mt-4 text-5xl leading-[.98] tracking-[-.045em] text-[#1d2b44] md:text-6xl">Your course should fit <em className="text-[#e85f4b]">you.</em></h2>
            <p className="mt-6 max-w-[400px] leading-7 text-[#5a6b68]">A course title only tells you so much. We look at teaching style, graduate outcomes, city, cost and the kind of person you want to become.</p>
            <div className="mt-8 flex flex-wrap gap-2">
              {fields.map((item, index) => <button type="button" key={item.label} onClick={() => setFieldIndex(index)} className={`rounded-full border px-4 py-2.5 text-sm font-semibold transition-colors ${fieldIndex === index ? 'border-[#527262] bg-[#527262] text-white' : 'border-[#b9cabb] text-[#527262] hover:bg-white/60'}`} data-testid={`button-field-${index}`}>{item.label}</button>)}
            </div>
          </div>
          <div className="relative min-h-[410px] overflow-hidden rounded-[2rem] bg-[#1d2b44] p-8 text-[#f9f5ec] md:p-12">
            <div className="absolute -right-20 -top-24 h-72 w-72 rounded-full border-[34px] border-[#e85f4b]/20" />
            <div className="absolute -bottom-32 -left-20 h-72 w-72 rounded-full border-[38px] border-[#f1c579]/15" />
            <div className="relative flex h-full flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[#e85f4b]"><FieldIcon size={25} /></span>
                <span className="rounded-full border border-white/20 px-3 py-1.5 text-xs font-bold text-white/70">{field.stat}</span>
              </div>
              <div className="mt-24">
                <p className="eyebrow text-[#f1c579]">A path with potential</p>
                <h3 className="font-display mt-4 max-w-[600px] text-4xl leading-[1.02] tracking-[-.04em] md:text-6xl">{field.title}</h3>
                <p className="mt-5 max-w-[550px] leading-7 text-white/70">{field.body}</p>
                <button type="button" onClick={openConsult} className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#f9f5ec] px-5 py-3 text-sm font-bold text-[#1d2b44] hover:bg-[#f1c579]" data-testid="button-field-guidance">Get course guidance <ArrowRight size={15} /></button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="process" className="scroll-mt-20 bg-[#faf8f2] py-24 md:py-32">
        <div className="section-wrap">
          <div className="mb-16 max-w-[650px]">
            <p className="eyebrow text-[#e85f4b]">A partnership, not a hand-off</p>
            <h2 className="font-display mt-4 text-5xl leading-[.98] tracking-[-.045em] text-[#1d2b44] md:text-7xl">From “what if?”<br /><span className="text-[#527262]">to “I’m here.”</span></h2>
          </div>
          <div className="grid border-t border-[#ddd4c7] md:grid-cols-5">
            {steps.map((step, index) => {
              const StepIcon = step.icon;
              return <article key={step.number} className="group border-b border-[#ddd4c7] py-8 md:border-b-0 md:border-r md:px-6 md:py-8 md:first:pl-0 md:last:border-r-0 md:last:pr-0" data-testid={`step-process-${step.number}`}>
                <div className="flex items-center justify-between"><span className="font-mono text-xs font-bold text-[#e85f4b]">{step.number}</span><StepIcon size={20} className="text-[#527262] transition-transform group-hover:-translate-y-1 group-hover:rotate-6" /></div>
                <h3 className="mt-12 font-display text-2xl leading-tight text-[#1d2b44]">{step.title}</h3>
                <p className="mt-4 text-sm leading-6 text-[#697487]">{step.body}</p>
                {index < steps.length - 1 && <div className="mt-7 hidden text-[#d0c6b7] md:block"><ArrowRight size={18} /></div>}
              </article>;
            })}
          </div>
        </div>
      </section>

      <section id="scholarships" className="scroll-mt-20 bg-[#e85f4b] py-20 text-[#fff9f0] md:py-28">
        <div className="section-wrap grid gap-10 lg:grid-cols-[1fr_.8fr] lg:items-center">
          <div>
            <p className="eyebrow text-[#f8d9a0]">Make your next step clearer</p>
            <h2 className="font-display mt-4 max-w-[700px] text-5xl leading-[.96] tracking-[-.05em] md:text-7xl">A brilliant education<br />needs a <em className="text-[#1d2b44]">realistic plan.</em></h2>
            <p className="mt-6 max-w-[550px] text-lg leading-8 text-white/80">Scholarships, funding routes and honest budgeting are part of the conversation from day one. We help you compare the full picture before you apply.</p>
            <button type="button" onClick={openConsult} className="mt-8 inline-flex items-center gap-3 rounded-full bg-[#1d2b44] px-6 py-4 text-sm font-bold text-white transition-transform hover:-translate-y-1" data-testid="button-scholarship-support">Ask about your application <ArrowRight size={16} /></button>
          </div>
          <div className="relative mx-auto h-[300px] w-full max-w-[480px]">
            <div className="absolute left-[10%] top-[5%] h-[240px] w-[80%] rotate-[-6deg] rounded-[2rem] border border-white/20 bg-[#f5c57e] p-7 text-[#1d2b44] shadow-2xl">
              <div className="flex justify-between text-xs font-bold"><span>AIMUNI / APPLICATION PLAN</span><span>STEP BY STEP</span></div>
              <div className="mt-10 grid grid-cols-3 gap-2 text-center text-[10px] font-bold uppercase tracking-[.08em]">
                <span className="rounded-xl bg-[#1d2b44]/10 px-2 py-3">Course</span>
                <span className="rounded-xl bg-[#1d2b44]/10 px-2 py-3">English</span>
                <span className="rounded-xl bg-[#1d2b44]/10 px-2 py-3">Visa</span>
              </div>
              <div className="mt-10 flex items-end justify-between"><span className="font-display text-4xl">Clear next steps</span><span className="text-right text-xs font-semibold">from first<br />question</span></div>
            </div>
            <div className="absolute bottom-[2%] right-[2%] grid h-20 w-20 rotate-6 place-items-center rounded-full border-4 border-[#e85f4b] bg-[#527262] text-center text-[10px] font-bold uppercase tracking-widest text-white shadow-xl">Plan<br />with<br />clarity</div>
          </div>
        </div>
      </section>

      <section className="bg-[#faf8f2] py-24 md:py-32">
        <div className="section-wrap">
          <div className="grid gap-12 lg:grid-cols-[.7fr_1.3fr] lg:items-start">
            <div><p className="eyebrow text-[#527262]">The human bit matters</p><h2 className="font-display mt-4 text-5xl leading-[.98] tracking-[-.045em] text-[#1d2b44] md:text-6xl">Good advice<br /><em className="text-[#e85f4b]">feels like this.</em></h2></div>
            <div className="max-w-[620px]">
              <figure className="rounded-[1.5rem] bg-[#e9f0e8] p-7 md:p-9"><div className="mb-8 flex gap-1 text-[#e85f4b]">{[1,2,3,4,5].map(star => <Sparkles size={13} key={star} />)}</div><blockquote className="font-display text-3xl leading-tight text-[#1d2b44]">“AimUni helped me understand my options and feel ready for my next step in the UK.”</blockquote><figcaption className="mt-7 text-xs font-bold uppercase tracking-[.1em] text-[#657084]">AimUni student · now studying in the UK</figcaption></figure>
            </div>
          </div>
        </div>
      </section>

      <section id="faqs" className="scroll-mt-20 bg-[#f2ecdf] py-24 md:py-32">
        <div className="section-wrap grid gap-12 lg:grid-cols-[.7fr_1.3fr]">
          <div><p className="eyebrow text-[#e85f4b]">Questions welcome</p><h2 className="font-display mt-4 text-5xl leading-[.98] tracking-[-.045em] text-[#1d2b44] md:text-6xl">No question<br /><em className="text-[#527262]">is too early.</em></h2><p className="mt-6 max-w-[330px] text-sm leading-6 text-[#687287]">The best plan starts with the question you are carrying around. Here are a few we hear often.</p></div>
          <div className="border-t border-[#d8cebf]">
            {faqs.map(([question, answer], index) => <div key={question} className="border-b border-[#d8cebf]">
              <button type="button" onClick={() => setFaqOpen(faqOpen === index ? null : index)} className="flex w-full items-center justify-between gap-6 py-6 text-left text-lg font-semibold text-[#1d2b44]" aria-expanded={faqOpen === index} data-testid={`button-faq-${index}`}>
                <span>{question}</span><ChevronDown size={19} className={`shrink-0 text-[#e85f4b] transition-transform ${faqOpen === index ? 'rotate-180' : ''}`} />
              </button>
              {faqOpen === index && <p className="max-w-[680px] pb-7 pr-8 text-sm leading-7 text-[#687287]" data-testid={`text-faq-answer-${index}`}>{answer}</p>}
            </div>)}
          </div>
        </div>
      </section>

      <section id="contact" className="scroll-mt-20 bg-[#1d2b44] py-24 text-[#f9f5ec] md:py-32">
        <div className="section-wrap relative overflow-hidden rounded-[2rem] border border-white/10 bg-[#263852] px-7 py-14 md:px-16">
          <div className="absolute -right-20 -top-28 h-80 w-80 rounded-full border-[42px] border-[#527262]/40" />
          <div className="relative z-10 grid gap-10 md:grid-cols-[1fr_auto] md:items-end">
            <div>
              <p className="eyebrow text-[#f1c579]">One conversation can change the map</p>
              <h2 className="font-display mt-4 max-w-[720px] text-5xl leading-[.96] tracking-[-.05em] md:text-7xl">Let’s make your<br /><span className="text-[#f1c579]">next move clearer.</span></h2>
              <p className="mt-6 max-w-[530px] text-lg leading-8 text-white/65">Tell Priyanka where you are starting from. She will help you see where you could go.</p>
              <div className="mt-6 flex flex-wrap gap-x-5 gap-y-3 text-sm text-white/80">
                <a href="mailto:infoaimuni@gmail.com" className="inline-flex items-center gap-2 hover:text-white" data-testid="link-contact-email"><Mail size={15} /> infoaimuni@gmail.com</a>
                <a href="https://wa.me/919739881992" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 hover:text-white" data-testid="link-contact-whatsapp"><MessageCircle size={15} /> WhatsApp: +91 97398 81992</a>
                <a href="tel:+919035351000" className="inline-flex items-center gap-2 hover:text-white" data-testid="link-contact-phone"><Phone size={15} /> Call: +91 90353 51000</a>
              </div>
            </div>
            <button type="button" onClick={openConsult} className="group inline-flex w-fit items-center gap-3 rounded-full bg-[#ef654e] px-6 py-4 text-sm font-bold text-white transition-transform hover:-translate-y-1" data-testid="button-final-consultation">Book your free consultation <ArrowRight size={17} className="transition-transform group-hover:translate-x-1" /></button>
          </div>
        </div>
      </section>

      <footer className="bg-[#1d2b44] pb-8 pt-4 text-[#f9f5ec]">
        <div className="section-wrap">
          <div className="grid gap-10 border-t border-white/15 py-12 md:grid-cols-[1.5fr_1fr_1fr_1fr]">
            <div><img src="/assets/aimuni-logo-cropped.png" alt="AimUni — Beyond Admission. Beyond Arrival." className="h-12 w-[150px] rounded-md bg-white object-contain p-1" /><p className="mt-5 max-w-[270px] text-sm leading-6 text-white/55">Beyond admission.<br />Beyond arrival.</p></div>
            <div><p className="eyebrow text-[#f1c579]">Explore</p><div className="mt-5 flex flex-col gap-3 text-sm text-white/65"><button type="button" className="text-left hover:text-white" onClick={() => scrollToSection('destinations')} data-testid="link-footer-destinations">Destinations</button><button type="button" className="text-left hover:text-white" onClick={() => scrollToSection('fields')} data-testid="link-footer-fields">Study fields</button><button type="button" className="text-left hover:text-white" onClick={() => scrollToSection('process')} data-testid="link-footer-process">How it works</button></div></div>
            <div><p className="eyebrow text-[#f1c579]">Support</p><div className="mt-5 flex flex-col gap-3 text-sm text-white/65"><button type="button" className="text-left hover:text-white" onClick={() => scrollToSection('scholarships')} data-testid="link-footer-scholarships">Scholarships</button><button type="button" className="text-left hover:text-white" onClick={() => scrollToSection('faqs')} data-testid="link-footer-faqs">FAQs</button><a href="mailto:infoaimuni@gmail.com" className="text-left hover:text-white" data-testid="link-footer-contact">Contact Priyanka</a></div></div>
            <div><p className="eyebrow text-[#f1c579]">Get in touch</p><div className="mt-5 flex flex-col gap-3 text-sm text-white/65"><p className="font-semibold text-white/80">Priyanka Madhukumar</p><a href="mailto:infoaimuni@gmail.com" className="flex items-center gap-2 hover:text-white" data-testid="link-footer-email"><Mail size={14} /> infoaimuni@gmail.com</a><a href="https://wa.me/919739881992" target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-white" data-testid="link-footer-whatsapp"><MessageCircle size={14} /> WhatsApp +91 97398 81992</a><a href="tel:+919035351000" className="flex items-center gap-2 hover:text-white" data-testid="link-footer-phone"><Phone size={14} /> Call +91 90353 51000</a><span className="flex items-center gap-2"><Clock3 size={14} /> Personal guidance for your next step</span></div></div>
          </div>
          <div className="flex flex-col justify-between gap-3 border-t border-white/15 pt-6 text-xs text-white/40 sm:flex-row"><span>© 2026 AimUni. Your next chapter starts here.</span><span>Built for curious minds everywhere.</span></div>
        </div>
      </footer>

      {selectedCountry && <div className="fixed inset-0 z-50 grid place-items-center bg-[#142034]/75 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={`${selectedCountry.name} destination`}>
        <div className="relative max-h-[90vh] w-full max-w-[580px] overflow-auto rounded-[1.75rem] bg-[#faf8f2] shadow-2xl">
          <img src={selectedCountry.image} alt={`${selectedCountry.name} destination`} className="h-52 w-full object-cover" />
          <button type="button" onClick={() => setSelectedCountry(null)} className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full bg-[#1d2b44]/80 text-white" aria-label="Close destination details" data-testid="button-close-destination"><X size={18} /></button>
          <div className="p-7 md:p-9"><p className="eyebrow" style={{ color: selectedCountry.accent }}>Destination guide</p><h2 className="font-display mt-3 text-5xl leading-none text-[#1d2b44]">{selectedCountry.name}</h2><p className="mt-4 leading-7 text-[#687287]">{selectedCountry.note} Our advisers will help you compare universities, entry requirements, costs and the life beyond the campus.</p><div className="mt-6 flex flex-wrap gap-2">{selectedCountry.tags.map(tag => <span key={tag} className="rounded-full bg-[#e9f0e8] px-3 py-2 text-xs font-bold text-[#527262]">{tag}</span>)}</div><button type="button" onClick={openConsult} className="mt-8 inline-flex items-center gap-2 rounded-full bg-[#ef654e] px-5 py-3 text-sm font-bold text-white" data-testid="button-country-consultation">Ask about {selectedCountry.name} <ArrowRight size={15} /></button></div>
        </div>
      </div>}

      {consultOpen && <div className="fixed inset-0 z-[60] grid place-items-center bg-[#142034]/80 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Book a free consultation">
        <div className="relative max-h-[92vh] w-full max-w-[560px] overflow-auto rounded-[1.75rem] bg-[#faf8f2] p-7 shadow-2xl md:p-10">
          <button type="button" onClick={() => setConsultOpen(false)} className="absolute right-5 top-5 grid h-9 w-9 place-items-center rounded-full bg-[#e9e1d5] text-[#1d2b44]" aria-label="Close consultation form" data-testid="button-close-consultation"><X size={18} /></button>
          {!submitted ? <><p className="eyebrow text-[#e85f4b]">A good place to start</p><h2 className="font-display mt-3 max-w-[420px] text-5xl leading-[.95] tracking-[-.04em] text-[#1d2b44]">Let’s find your way in.</h2><p className="mt-4 text-sm leading-6 text-[#687287]">Share a few details and an AimUni adviser will be in touch to arrange your relaxed, no-pressure consultation.</p><form onSubmit={submitConsult} className="mt-7 grid gap-4">
            <label className="grid gap-1.5 text-xs font-bold text-[#33435e]">Your name<input required name="name" placeholder="What should we call you?" className="rounded-xl border border-[#d8cebf] bg-white/60 px-4 py-3.5 text-sm font-normal outline-none transition focus:border-[#e85f4b] focus:ring-2 focus:ring-[#e85f4b]/15" data-testid="input-consult-name" /></label>
            <label className="grid gap-1.5 text-xs font-bold text-[#33435e]">Email address<input required type="email" name="email" placeholder="you@example.com" className="rounded-xl border border-[#d8cebf] bg-white/60 px-4 py-3.5 text-sm font-normal outline-none transition focus:border-[#e85f4b] focus:ring-2 focus:ring-[#e85f4b]/15" data-testid="input-consult-email" /></label>
            <div className="grid gap-4 sm:grid-cols-2"><label className="grid gap-1.5 text-xs font-bold text-[#33435e]">I’m interested in<select name="country" className="rounded-xl border border-[#d8cebf] bg-white/60 px-4 py-3.5 text-sm font-normal outline-none focus:border-[#e85f4b]" data-testid="select-consult-country"><option>Not sure yet</option>{countries.map(country => <option key={country.name}>{country.name}</option>)}</select></label><label className="grid gap-1.5 text-xs font-bold text-[#33435e]">Study level<select name="level" className="rounded-xl border border-[#d8cebf] bg-white/60 px-4 py-3.5 text-sm font-normal outline-none focus:border-[#e85f4b]" data-testid="select-consult-level"><option>Undergraduate</option><option>Postgraduate</option><option>PhD / Research</option><option>Still exploring</option></select></label></div>
            {submissionError && <p role="alert" className="rounded-xl bg-[#f8e6dc] px-4 py-3 text-sm leading-6 text-[#8f3d30]" data-testid="text-consultation-error">{submissionError}</p>}
            <button type="submit" disabled={isSubmitting} className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-[#ef654e] px-5 py-4 text-sm font-bold text-white disabled:cursor-wait disabled:opacity-70" data-testid="button-submit-consultation">{isSubmitting ? 'Sending request…' : 'Request my consultation'} <ArrowRight size={16} /></button>
          </form></> : <div className="py-12 text-center"><span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[#e9f0e8] text-[#527262]"><Check size={30} /></span><h2 className="font-display mt-6 text-5xl leading-none text-[#1d2b44]">You’re on your way.</h2><p className="mx-auto mt-4 max-w-[340px] text-sm leading-6 text-[#687287]">Thank you. An AimUni adviser will get back to you soon to arrange your conversation.</p><button type="button" onClick={() => setConsultOpen(false)} className="mt-8 rounded-full border border-[#cfc5b6] px-5 py-3 text-sm font-bold text-[#1d2b44]" data-testid="button-close-confirmation">Done</button></div>}
        </div>
      </div>}
    </main>
  );
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;