# AimUni API backend

This Express 5 / Node API stores consultation requests in MongoDB using Mongoose.

## MongoDB setup

1. Create a MongoDB database named `aimuni` (MongoDB Atlas works).
2. Add the database connection URI as `MONGODB_URI`.
3. For Replit, add `MONGODB_URI` in **Tools → Secrets**. Do not commit a real URI.
4. For a local copy, use the placeholder in `.env.example` as a guide and keep the actual `.env` file private.

The API creates the `consultation_requests` collection automatically when the first request is saved. If MongoDB is not configured, the API stays available for the website preview but returns HTTP 503 for consultation submissions rather than pretending the request was stored.

## API

`POST /api/consultations`

```json
{
  "name": "Student name",
  "email": "student@example.com",
  "country": "United Kingdom",
  "level": "Undergraduate"
}
```

The route validates the request against the shared OpenAPI contract and saves the enquiry with a server-generated creation time.