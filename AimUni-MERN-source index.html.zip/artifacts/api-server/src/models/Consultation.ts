import mongoose, { model, Schema } from "mongoose";

const consultationSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 120,
    },
    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      maxlength: 254,
    },
    country: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100,
    },
    level: {
      type: String,
      required: true,
      enum: ["Undergraduate", "Postgraduate", "PhD / Research", "Still exploring"],
    },
  },
  {
    collection: "consultation_requests",
    timestamps: true,
    versionKey: false,
  },
);

export const Consultation =
  mongoose.models.Consultation ??
  model("Consultation", consultationSchema);