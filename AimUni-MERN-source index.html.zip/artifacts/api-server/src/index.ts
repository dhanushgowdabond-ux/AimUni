import "dotenv/config";
import app from "./app";
import { logger } from "./lib/logger";
import { connectMongo, isMongoConfigured } from "./lib/mongodb";

void connectMongo().then((connected) => {
  if (!connected && !isMongoConfigured()) {
    logger.warn("MONGODB_URI is not configured; consultation requests will not be stored");
  }
});

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});
