import mongoose from "mongoose";
import { logger } from "./logger";

let connectionAttempt: Promise<boolean> | null = null;

export async function connectMongo(): Promise<boolean> {
  const uri = process.env.MONGODB_URI?.trim();
  if (!uri) {
    return false;
  }

  if (mongoose.connection.readyState === 1) {
    return true;
  }

  if (!connectionAttempt) {
    connectionAttempt = mongoose
      .connect(uri, { serverSelectionTimeoutMS: 5_000 })
      .then(() => {
        logger.info("MongoDB connected");
        return true;
      })
      .catch((err: unknown) => {
        logger.error({ err }, "MongoDB connection failed");
        return false;
      })
      .finally(() => {
        connectionAttempt = null;
      });
  }

  return connectionAttempt;
}

export function isMongoConfigured(): boolean {
  return Boolean(process.env.MONGODB_URI?.trim());
}