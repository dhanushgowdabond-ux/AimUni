import { Router, type IRouter, type Response } from "express";
import {
  CreateConsultationBody,
  CreateConsultationResponse,
  type ApiError,
} from "@workspace/api-zod";
import { isMongoConfigured, connectMongo } from "../lib/mongodb";
import { Consultation } from "../models/Consultation";

const router: IRouter = Router();

function sendApiError(
  res: Response,
  status: 400 | 500 | 503,
  message: string,
): void {
  const payload: ApiError = { error: message };
  res.status(status).json(payload);
}

router.post("/consultations", async (req, res): Promise<void> => {
  const parsed = CreateConsultationBody.safeParse(req.body);
  if (!parsed.success) {
    sendApiError(res, 400, "Enter a valid name, email, destination, and study level.");
    return;
  }

  if (!isMongoConfigured()) {
    sendApiError(res, 503, "Consultation storage is not configured yet.");
    return;
  }

  const connected = await connectMongo();
  if (!connected) {
    sendApiError(res, 503, "Consultation storage is temporarily unavailable. Please try again.");
    return;
  }

  try {
    const consultation = await Consultation.create(parsed.data);
    res.status(201).json(
      CreateConsultationResponse.parse({
        id: consultation.id,
        message: "Your consultation request has been saved.",
        createdAt: consultation.createdAt,
      }),
    );
  } catch (err) {
    req.log.error({ err }, "Unable to save consultation request");
    sendApiError(res, 500, "We could not save your request. Please try again.");
  }
});

export default router;