import { Router, type IRouter } from "express";
import consultationsRouter from "./consultations";
import healthRouter from "./health";

const router: IRouter = Router();

router.use(healthRouter);
router.use(consultationsRouter);

export default router;
